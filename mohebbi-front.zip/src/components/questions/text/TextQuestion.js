import TextTags from "../../../pages/dataSet/TextTags";
import {useSelector} from "react-redux";
import {useMemo, useState} from "react";
import {client, getHeaders} from "../../../api/client";
import {useNavigate} from "react-router";

export const TextQuestion = (props) => {
    const question = props.question
    const tags = useSelector((state) => state.tags.tags)
    const [selectedTags, setSelectedTags] = useState([])
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate();

    const handleOnTagClick = (tag) => {
        setSelectedTags([...selectedTags, tag.id])
    }

    const tagQuestion = async () => {
        setLoading(true)
        await client.post(`/newsletters/${props.question.id}/data-set`, {
            tagIds: selectedTags
        }, {
            headers: getHeaders()
        })
        setSelectedTags([])
        setLoading(false)
    }

    const handleOnConfirmClick = async () => {
        try {
            await tagQuestion();
            props.onNextQuestion();
        }catch (error) {
            alert("error")
        }
    }

    const handleOnFinishClick = async () => {
        if(selectedTags) {
            try {
                await tagQuestion();
            }catch (error) {
                alert("error")
            }
        }
        navigate("/")
    }

    return <>
        <div className="set-text-wrapper">
            <div className="text-container">
                <h2>{props.question?.title}</h2>
                <div>{props.question?.description}</div>
            </div>
        </div>
        <div className="tags-container">
            {tags.map((tag) => {
                return <TextTags key={tag.id} tag={tag} isSelected={selectedTags.includes(tag.id)} onClick={handleOnTagClick}/>
            })}
        </div>
        <div className="buttons-container">
            <button className="submit-button button" onClick={handleOnConfirmClick} disabled={selectedTags.length === 0 || loading}>تایید</button>
            <button className="submit-button button" onClick={handleOnFinishClick} disabled={loading}>اتمام</button>
        </div>
    </>
}
