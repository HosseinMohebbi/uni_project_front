import { configureStore } from '@reduxjs/toolkit'
import { userReducer } from './user.slice';
import {textReducer} from "./text.slice";
import {tagsReducer} from "./tags.slice";

export const store = configureStore({
  reducer: {
    user: userReducer,
    text: textReducer,
    tags: tagsReducer,
  }
})
